
document.getElementById('boton-receta1').addEventListener('click', function(){
	
	var ingredientes = ["Claras de huevo","Azúcar blanca","Leche condensada","Gelatina sin sabor","Limones"];

	var unitHuevo = 5;
	var gramsAzucar = 150;
	var gramsLeche = 200;
	var sobreGelatina = 1;
	var unitLimon = 4;

console.log("Para preparar un Postre de Limón debes realizar lo siguiente:");

console.log("Adicionar las "+ unitHuevo +" "+ ingredientes[0] +" en un Bowl y batir con los "+ gramsAzucar +" gramos de "+ ingredientes[1] +".");

console.log("Adicionar los "+ gramsLeche +" gramos de "+ ingredientes[2] +" y batir bien.");

console.log("Adicionar el zumo de "+ unitLimon +" "+ ingredientes[4] +" y "+ sobreGelatina +" sobre de "+ ingredientes[3] +" hidratada en agua tibia.");

console.log("Deposita la mezcla en moldes individaules y refrigera");

});

document.getElementById('boton-receta2').addEventListener('click', function(){
	
	var ingredientes = ["Ginebra","Vermouth Seco","Aceituna"];
	var onzasGin = 2.5;
	var onzasVermouth = 0.5;
	var unitAceituna = 1;
	
	console.log("Para preparar un Martini básico debes realizar lo siguiente:");
	console.log("Vertir las "+ onzasGin +" de "+ ingredientes[0] +" en una coctelera.");
	console.log("Añadir "+ onzasVermouth +" onzas de "+ ingredientes[1] +".");
	console.log("Servir en una copa tipo Martini y añadir "+ unitAceituna +" "+ ingredientes[2] +".");
	
});